import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Enum para tipos de canais de comunicação
 */
export const channelTypes = mysqlEnum("channelType", ["whatsapp", "messenger", "instagram", "email", "chat"]);

/**
 * Enum para status de atendimento
 */
export const attendanceStatus = mysqlEnum("attendanceStatus", ["pending", "in_progress", "resolved", "closed"]);

/**
 * Tabela de especialidades médicas
 */
export const specialties = mysqlTable("specialties", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Tabela de canais de comunicação
 */
export const channels = mysqlTable("channels", {
  id: int("id").autoincrement().primaryKey(),
  type: channelTypes.notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Tabela de conversas entre pacientes e atendentes
 */
export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull().references(() => users.id),
  attendantId: int("attendantId").references(() => users.id),
  channelId: int("channelId").notNull().references(() => channels.id),
  status: attendanceStatus.default("pending").notNull(),
  subject: varchar("subject", { length: 255 }),
  priority: mysqlEnum("priority", ["low", "medium", "high"]).default("medium").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  closedAt: timestamp("closedAt"),
});

/**
 * Tabela de mensagens em conversas
 */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull().references(() => conversations.id),
  senderId: int("senderId").notNull().references(() => users.id),
  content: text("content").notNull(),
  messageType: mysqlEnum("messageType", ["text", "image", "file", "system"]).default("text").notNull(),
  isRead: int("isRead").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Tabela de agendamentos de consultas
 */
export const appointments = mysqlTable("appointments", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull().references(() => users.id),
  doctorId: int("doctorId").notNull().references(() => users.id),
  specialtyId: int("specialtyId").notNull().references(() => specialties.id),
  conversationId: int("conversationId").references(() => conversations.id),
  appointmentDate: timestamp("appointmentDate").notNull(),
  status: mysqlEnum("appointmentStatus", ["scheduled", "confirmed", "completed", "cancelled"]).default("scheduled").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Tabela de métricas de desempenho de atendentes
 */
export const attendantMetrics = mysqlTable("attendantMetrics", {
  id: int("id").autoincrement().primaryKey(),
  attendantId: int("attendantId").notNull().references(() => users.id),
  totalAttendances: int("totalAttendances").default(0).notNull(),
  averageResponseTime: int("averageResponseTime").default(0).notNull(), // em segundos
  resolvedConversations: int("resolvedConversations").default(0).notNull(),
  customerSatisfaction: int("customerSatisfaction").default(0).notNull(), // 0-100
  appointmentsScheduled: int("appointmentsScheduled").default(0).notNull(),
  date: timestamp("date").defaultNow().notNull(),
});

/**
 * Tabela de respostas rápidas/templates
 */
export const quickReplies = mysqlTable("quickReplies", {
  id: int("id").autoincrement().primaryKey(),
  attendantId: int("attendantId").notNull().references(() => users.id),
  title: varchar("title", { length: 100 }).notNull(),
  content: text("content").notNull(),
  category: varchar("category", { length: 50 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/**
 * Tabela de informações do perfil de usuário estendida
 */
export const userProfiles = mysqlTable("userProfiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique().references(() => users.id),
  userType: mysqlEnum("userType", ["patient", "attendant", "doctor", "manager"]).notNull(),
  phone: varchar("phone", { length: 20 }),
  specialtyId: int("specialtyId").references(() => specialties.id),
  department: varchar("department", { length: 100 }),
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/**
 * Tipos exportados para uso em procedures
 */
export type Specialty = typeof specialties.$inferSelect;
export type InsertSpecialty = typeof specialties.$inferInsert;

export type Channel = typeof channels.$inferSelect;
export type InsertChannel = typeof channels.$inferInsert;

export type Conversation = typeof conversations.$inferSelect;
export type InsertConversation = typeof conversations.$inferInsert;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = typeof appointments.$inferInsert;

export type AttendantMetrics = typeof attendantMetrics.$inferSelect;
export type InsertAttendantMetrics = typeof attendantMetrics.$inferInsert;

export type QuickReply = typeof quickReplies.$inferSelect;
export type InsertQuickReply = typeof quickReplies.$inferInsert;

export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = typeof userProfiles.$inferInsert;