import { MessageCircle, Mail, Instagram, MessageSquare } from "lucide-react";

interface ChannelIconProps {
  type: "whatsapp" | "messenger" | "instagram" | "email" | "chat";
  size?: "sm" | "md" | "lg";
}

export function ChannelIcon({ type, size = "md" }: ChannelIconProps) {
  const sizeMap = {
    sm: "h-4 w-4",
    md: "h-5 w-5",
    lg: "h-6 w-6",
  };

  const iconSize = sizeMap[size];

  switch (type) {
    case "whatsapp":
      return <MessageCircle className={`${iconSize} text-green-600`} />;
    case "messenger":
      return <MessageSquare className={`${iconSize} text-blue-600`} />;
    case "instagram":
      return <Instagram className={`${iconSize} text-pink-600`} />;
    case "email":
      return <Mail className={`${iconSize} text-gray-600`} />;
    case "chat":
      return <MessageCircle className={`${iconSize} text-indigo-600`} />;
    default:
      return <MessageCircle className={`${iconSize} text-gray-600`} />;
  }
}

export function getChannelColor(type: string): string {
  switch (type) {
    case "whatsapp":
      return "bg-green-100 text-green-800";
    case "messenger":
      return "bg-blue-100 text-blue-800";
    case "instagram":
      return "bg-pink-100 text-pink-800";
    case "email":
      return "bg-gray-100 text-gray-800";
    case "chat":
      return "bg-indigo-100 text-indigo-800";
    default:
      return "bg-gray-100 text-gray-800";
  }
}

export function getChannelName(type: string): string {
  switch (type) {
    case "whatsapp":
      return "WhatsApp";
    case "messenger":
      return "Messenger";
    case "instagram":
      return "Instagram";
    case "email":
      return "Email";
    case "chat":
      return "Chat";
    default:
      return "Desconhecido";
  }
}
