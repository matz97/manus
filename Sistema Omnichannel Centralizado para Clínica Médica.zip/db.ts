import { eq, and, desc, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users, 
  InsertUserProfile,
  userProfiles,
  conversations,
  messages,
  channels,
  specialties,
  appointments,
  attendantMetrics,
  quickReplies,
  InsertConversation,
  InsertMessage,
  InsertAppointment,
  InsertAttendantMetrics,
  InsertQuickReply,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// User Profile functions
export async function createUserProfile(profile: InsertUserProfile) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(userProfiles).values(profile);
}

export async function getUserProfile(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Conversation functions
export async function createConversation(conversation: InsertConversation) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(conversations).values(conversation);
  return result;
}

export async function getConversationById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getConversationsByPatientId(patientId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(conversations)
    .where(eq(conversations.patientId, patientId))
    .orderBy(desc(conversations.createdAt));
}

export async function getConversationsByAttendantId(attendantId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(conversations)
    .where(eq(conversations.attendantId, attendantId))
    .orderBy(desc(conversations.createdAt));
}

export async function getPendingConversations() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(conversations)
    .where(eq(conversations.status, "pending"))
    .orderBy(desc(conversations.createdAt));
}

export async function updateConversationStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(conversations)
    .set({ status: status as any, updatedAt: new Date() })
    .where(eq(conversations.id, id));
}

export async function assignConversationToAttendant(conversationId: number, attendantId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(conversations)
    .set({ attendantId, status: "in_progress", updatedAt: new Date() })
    .where(eq(conversations.id, conversationId));
}

// Message functions
export async function createMessage(message: InsertMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(messages).values(message);
  return result;
}

export async function getMessagesByConversationId(conversationId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(messages.createdAt);
}

export async function markMessagesAsRead(conversationId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(messages)
    .set({ isRead: 1 })
    .where(eq(messages.conversationId, conversationId));
}

// Channel functions
export async function getChannels() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(channels).where(eq(channels.isActive, 1));
}

export async function getChannelById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(channels).where(eq(channels.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Specialty functions
export async function getSpecialties() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(specialties);
}

export async function getSpecialtyById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(specialties).where(eq(specialties.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Appointment functions
export async function createAppointment(appointment: InsertAppointment) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(appointments).values(appointment);
  return result;
}

export async function getAppointmentsByPatientId(patientId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(appointments)
    .where(eq(appointments.patientId, patientId))
    .orderBy(desc(appointments.appointmentDate));
}

export async function getUpcomingAppointments(days: number = 7) {
  const db = await getDb();
  if (!db) return [];
  const now = new Date();
  const futureDate = new Date(now.getTime() + days * 24 * 60 * 60 * 1000);
  
  return await db.select().from(appointments)
    .where(and(
      gte(appointments.appointmentDate, now),
      lte(appointments.appointmentDate, futureDate),
      eq(appointments.status, "scheduled")
    ))
    .orderBy(appointments.appointmentDate);
}

// Attendant Metrics functions
export async function getAttendantMetrics(attendantId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(attendantMetrics)
    .where(eq(attendantMetrics.attendantId, attendantId))
    .orderBy(desc(attendantMetrics.date))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateAttendantMetrics(metrics: InsertAttendantMetrics) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(attendantMetrics).values(metrics);
}

export async function getAllAttendantMetrics() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(attendantMetrics)
    .orderBy(desc(attendantMetrics.date));
}

// Quick Reply functions
export async function createQuickReply(reply: InsertQuickReply) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(quickReplies).values(reply);
  return result;
}

export async function getQuickRepliesByAttendantId(attendantId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(quickReplies)
    .where(eq(quickReplies.attendantId, attendantId))
    .orderBy(quickReplies.title);
}

export async function deleteQuickReply(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(quickReplies).where(eq(quickReplies.id, id));
}

// TODO: add more feature queries here as your schema grows.
