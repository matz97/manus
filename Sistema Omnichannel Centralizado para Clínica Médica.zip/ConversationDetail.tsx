import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { ArrowLeft, Send } from "lucide-react";

export default function ConversationDetail() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/conversation/:id");
  const conversationId = params?.id ? Number(params.id) : null;
  const [messageContent, setMessageContent] = useState("");

  const { data: conversation } = trpc.conversations.getById.useQuery(
    { id: conversationId || 0 },
    { enabled: !!conversationId }
  );

  const { data: messages } = trpc.messages.list.useQuery(
    { conversationId: conversationId || 0 },
    { enabled: !!conversationId }
  );

  const sendMessageMutation = trpc.messages.send.useMutation({
    onSuccess: () => {
      setMessageContent("");
    },
  });

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!conversationId || !messageContent.trim()) return;

    await sendMessageMutation.mutateAsync({
      conversationId,
      content: messageContent,
      messageType: "text",
    });
  };

  if (!user || !conversationId) {
    return <div className="flex items-center justify-center min-h-screen">Carregando...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => window.history.back()}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {conversation?.subject || "Conversa"}
            </h1>
            <p className="text-sm text-gray-600">
              Status: {conversation?.status} • Prioridade: {conversation?.priority}
            </p>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="flex flex-col h-[calc(100vh-200px)]">
          {/* Mensagens */}
          <CardContent className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
            {messages && messages.length > 0 ? (
              messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.senderId === user.id ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-xs px-4 py-3 rounded-lg ${
                      message.senderId === user.id
                        ? "bg-blue-600 text-white"
                        : "bg-white text-gray-900 border border-gray-200"
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <p className={`text-xs mt-2 ${
                      message.senderId === user.id ? "text-blue-100" : "text-gray-500"
                    }`}>
                      {new Date(message.createdAt).toLocaleTimeString("pt-BR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <div className="flex items-center justify-center h-full">
                <p className="text-gray-500">Nenhuma mensagem ainda. Comece a conversa!</p>
              </div>
            )}
          </CardContent>

          {/* Input de Mensagem */}
          <CardHeader className="border-t bg-white">
            <form onSubmit={handleSendMessage} className="flex gap-2">
              <input
                type="text"
                value={messageContent}
                onChange={(e) => setMessageContent(e.target.value)}
                placeholder="Digite sua mensagem..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Button
                type="submit"
                disabled={!messageContent.trim()}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </CardHeader>
        </Card>
      </main>
    </div>
  );
}
