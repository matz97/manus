import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from "recharts";

interface PerformanceChartProps {
  data: Array<{
    name: string;
    atendimentos: number;
    resolvidas: number;
    satisfacao: number;
  }>;
  title: string;
  description?: string;
}

export function PerformanceChart({ data, title, description }: PerformanceChartProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="atendimentos" fill="#3b82f6" name="Atendimentos" />
            <Bar dataKey="resolvidas" fill="#10b981" name="Resolvidas" />
            <Bar dataKey="satisfacao" fill="#f59e0b" name="Satisfação %" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

interface SatisfactionTrendProps {
  data: Array<{
    date: string;
    satisfaction: number;
  }>;
}

export function SatisfactionTrend({ data }: SatisfactionTrendProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Tendência de Satisfação</CardTitle>
        <CardDescription>Evolução da satisfação do cliente ao longo do tempo</CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <Legend />
            <Line
              type="monotone"
              dataKey="satisfaction"
              stroke="#3b82f6"
              name="Satisfação (%)"
              strokeWidth={2}
              dot={{ fill: "#3b82f6", r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
