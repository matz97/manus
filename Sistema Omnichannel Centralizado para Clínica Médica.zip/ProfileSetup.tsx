import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Loader2 } from "lucide-react";

export default function ProfileSetup() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [userType, setUserType] = useState<"patient" | "attendant" | "doctor" | "manager">("patient");
  const [phone, setPhone] = useState("");
  const [department, setDepartment] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const createProfileMutation = trpc.userProfiles.createProfile.useMutation({
    onSuccess: () => {
      if (userType === "patient") {
        setLocation("/patient");
      } else if (userType === "attendant") {
        setLocation("/attendant");
      } else {
        setLocation("/manager");
      }
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await createProfileMutation.mutateAsync({
        userType,
        phone: phone || undefined,
        department: department || undefined,
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) {
    return <div className="flex items-center justify-center min-h-screen">Carregando...</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Configure seu Perfil</CardTitle>
          <CardDescription>
            Bem-vindo, {user.name}! Escolha seu tipo de usuário para continuar.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Tipo de Usuário</label>
              <select
                value={userType}
                onChange={(e) => setUserType(e.target.value as any)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="patient">Paciente</option>
                <option value="attendant">Atendente</option>
                <option value="doctor">Médico</option>
                <option value="manager">Gerente</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Telefone (opcional)</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="(11) 99999-9999"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {(userType === "attendant" || userType === "doctor") && (
              <div className="space-y-2">
                <label className="text-sm font-medium">Departamento/Especialidade</label>
                <input
                  type="text"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  placeholder="Ex: Cardiologia"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            )}

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Configurando...
                </>
              ) : (
                "Continuar"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
